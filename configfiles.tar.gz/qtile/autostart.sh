#!/bin/sh
#xrandr --output DP-0 --mode 1920x1080 --rate 144 --right-of eDP-1-1
#feh --bg-scale /usr/share/endeavouros/backgrounds/endeavouros-wallpaper.png
#nvidia-settings --load-config-only & disown
nitrogen --restore & disown
picom & disown

#xcompmgr & disown

#sudo system76-power daemon & disown

# Low battery notifier
#~/.config/qtile/scripts/check_battery.sh & disown

# Start welcome
# eos-welcome & disown

#/usr/bin/lxqt-policykit-agent & disown # start polkit agent from LXDE/LXQT
#/usr/lib/xfce-polkit/xfce-polkit & disown
#dunst & disown
/usr/lib/polkit-kde-authentication-agent-1 & disown
#xfce4-clipman & disown
/usr/lib/mate-settings-daemon/mate-settings-daemon & disown

#gpu-screen-recorder-gtk & disown
spectacle -s & disown
redshift-gtk & disown
#steam & disown
#discord & disown
#spotify  & disown

lxsession -s=Qtile -a & disown
#xfce4-session & disown

blueman-applet & disown
nm-applet & disown
#mullvad-vpn & disown
#cbatticon & disown
#volumeicon & disown
#prime-offload & disown
optimus-manager-qt & disown
caffeine start & disown
export QT_QPA_PLATFORMTHEME=qt5ct
